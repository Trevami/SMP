#!/usr/bin/env python3

import numpy as np

import ex_3_1
import ex_3_2

if __name__ == "__main__":
