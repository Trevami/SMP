#!/usr/bin/env python3

import numpy as np
import scipy.constants

def force(r_ij, m_i, m_j, g):
    pass

def step_euler(x, v, dt, mass, g, forces):
    pass

def forces(x, masses, g):
    pass

if __name__ == "__main__":
    import matplotlib.pyplot as plt
