#!/usr/bin/env python3

import numpy as np

import ex_2_1

def force(mass, gravity, v, gamma, v_0):
    pass

def run(x, v, dt, mass, gravity, gamma, v_0):
    pass

if __name__ == "__main__":
    import matplotlib.pyplot as plt
