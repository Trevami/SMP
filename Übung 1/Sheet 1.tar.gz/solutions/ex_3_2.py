#!/usr/bin/env python3

import numpy as np

import ex_3_1

def step_symplectic_euler(x, v, dt, mass, g):
    pass

def step_velocity_verlet(x, v, dt, mass, g, force_old):
    pass

if __name__ == "__main__":
    pass
