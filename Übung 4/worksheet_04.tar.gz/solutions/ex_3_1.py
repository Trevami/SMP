import numpy as np
from tqdm import tqdm
import pickle

def step_vv(x, v, f, dt):
    """
    Perform a single step of the velocity Verlet algorithm
    x: position
    v: velocity
    f: force
    dt: time step
    """

    # Update position
    x += v*dt + 0.5*f*dt**2

    # Half update of velocity
    v += 0.5*f*dt

    # Update force
    f = np.zeros_like(f)

    # Second half update of velocity
    v += 0.5*f*dt

    return x, v, f

def step_vv_langevin(x, v, f, dt, gamma, T):
    

def initialize_system(n_particles):
    """
    Initialize the system
    n_particles: number of particles
    """

    x = np.zeros((n_particles, 3))
    v = np.zeros((n_particles, 3))
    f = np.zeros((n_particles, 3))

    return x, v, f

def compute_instaneous_temperature(v):


if __name__ == "__main__":
    # System parameters

    # Lists for observables
    temperature = []
    particle_speeds = []
    particle_velocities = []
    particle_positions = []

    # Initialize the system
    x, v, f = initialize_system(N_PARTICLES)

    # Perform time integration
    for i in tqdm(range(int(T_INT/DT))):
        x, v, f = step_vv_langevin(x, v, f, DT, GAMMA, T)
        temperature.append(compute_instaneous_temperature(v))
        particle_velocities.append(v.copy())
        particle_speeds.append(np.linalg.norm(v, axis=1))
        particle_positions.append(x.copy())

    # Write the observables to file
    data = {
        "temperature": np.array(temperature),
        "particle_speeds": np.array(particle_speeds),
        "particle_velocities": np.array(particle_velocities),
        "particle_positions": np.array(particle_positions),
        "DT": DT,
        "T": T,
    }
    pickle.dump(data, open("data.pkl", "wb"))
