#!/usr/bin/env python3

import numpy as np
import scipy.linalg


def lj_potential(r_ij: np.ndarray) -> float:

    pass

def lj_force(r_ij: np.ndarray) -> np.ndarray:

    pass

if __name__ == "__main__":
    import matplotlib.pyplot as plt

    pass
