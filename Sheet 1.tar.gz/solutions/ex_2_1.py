#!/usr/bin/env python3

import numpy as np

def force(mass, gravity):
    pass

def step_euler(x, v, dt, mass, gravity, f):
    pass

if __name__ == "__main__":
    pass
